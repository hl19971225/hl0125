package net.wanho.mapper;

import net.wanho.controller.DownloadVO;
import net.wanho.po.Role;
import org.springframework.dao.DuplicateKeyException;

import java.util.List;

public interface RoleMapper {


        // 查询
        List<Role> selectAllRole(Role role);

        // 多选删除
        void deleteChecked(int[] ids);

        // 添加
        int insertBatch(List<Role> roleList) throws DuplicateKeyException;
        //修改
        void updateRole(Role role);

        // 查询回显数据
        Role selectById(Integer id);

        // 校验重名
        Role selectByName(String menuName);

        List<String> checkRoleName(List<String> nameList);

        List<Role> selectByDownloadVO(DownloadVO downloadVO);

}

package net.wanho.mapper;

import net.wanho.po.Menu;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface MenuMapper {

    List<Menu> getParentMenus(String account);

    List<Menu> getSonMenus(Integer pid);

    List<Menu> getAllParentMenu();

    void insertMenu(Menu menu);

    void insertMenuRole(@Param("roleArray") int[] checkedRoles,@Param("menuId")  Integer menuId);

    void deleteMenu(int menuId);

}

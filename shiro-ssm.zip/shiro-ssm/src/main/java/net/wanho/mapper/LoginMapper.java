package net.wanho.mapper;

import net.wanho.po.User;

import java.util.Set;

public interface LoginMapper {


    User selectByAccount(String inputAccount);

    Set<String> selectRolesByAccout(String accout);

}

package net.wanho.util;

import cn.afterturn.easypoi.excel.entity.params.ExcelExportEntity;
import cn.afterturn.easypoi.excel.export.styler.ExcelExportStylerDefaultImpl;
import org.apache.poi.ss.usermodel.*;


/*
    @Excel(name = "工资",numFormat="#,##0.00")
    private Double salary;
    numFormat="#,##0.00" 在导出时，会将num类型转换成 字符串，有问题
 */

public class MyExcelExportStyle extends ExcelExportStylerDefaultImpl {

    // private CellStyle cellStyle;

    public MyExcelExportStyle(Workbook workbook) {
        super(workbook);
    }

    // 设置 cellStyle 样式
    private void setCellStyle(CellStyle cellStyle, String type) {
        // 额外的通用设置
        // 设置边框
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderLeft(BorderStyle.THIN);
        cellStyle.setBorderRight(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);

        // money 特殊处理
        if ("money".equals(type)) {
            // 设置水平对齐
            cellStyle.setAlignment(HorizontalAlignment.CENTER);
            // 设置垂直对齐
            cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            // 格式化单元格
            DataFormat dataFormat = workbook.createDataFormat();
            cellStyle.setDataFormat(dataFormat.getFormat("#,##0.00"));
            cellStyle.setWrapText(true);//自动换行
        }

    }


    @Override
    public CellStyle getStyles(boolean noneStyler, ExcelExportEntity entity) {
        // 判断是否需要格式化
        if (entity != null && "money".equals(entity.getDict())) {

            CellStyle moneyCellStyle = workbook.createCellStyle();
            setCellStyle(moneyCellStyle, "money");
            return moneyCellStyle;
        }

        CellStyle superCellStyle = super.getStyles(noneStyler, entity);
        setCellStyle(superCellStyle, null);
        return superCellStyle;
    }
}

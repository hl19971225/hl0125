package net.wanho.util;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Component
public class RedisUtil {
    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 根据 key 获得值
     *
     * @param key
     * @return
     */
    public <T> T get(String key) {
        return (T) redisTemplate.opsForValue().get(key);
    }

    /**
     * 设置 key ，value  30分钟自动过期
     *
     * @param key
     * @param value
     */
    public void set(String key, Object value, long expireTime) {
        // 如果传参 expireTime> 0 ，可设置失效时间，默认分钟;否则 永久保存
        if (expireTime > 0) {
            redisTemplate.opsForValue().set(key, value, expireTime, TimeUnit.MINUTES);
            return;
        }
        redisTemplate.opsForValue().set(key, value);

    }

    /**
     * 根据 key 删除
     *
     * @param key
     */
    public void delete(String key) {
        redisTemplate.delete(key);
    }
}

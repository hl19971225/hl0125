package net.wanho.util;

import org.apache.shiro.crypto.hash.Md5Hash;
import org.springframework.beans.factory.annotation.Value;

public class MD5Util {

    @Value("${shiro.hashIterations}")
    private static int hashIterations ;

    public static void main(String[] args) {

        String pwd = "123";

        // System.out.println(new Md5Hash(source).toBase64());
        // System.out.println(new Md5Hash(pwd).toString());
        // 密码 + 盐值 + 加盐次数 0192023a7bbd73250516f069df18b500
        System.out.println(new Md5Hash(pwd,"admin",1024).toString());
        System.out.println(new Md5Hash(pwd,"hr01",1024).toString());
        System.out.println(new Md5Hash(pwd,"user01",1024).toString());
        System.out.println(new Md5Hash(pwd,"user02",1024).toString());

    }

    public  static  String getMD5Pwd(String pwd,String salt){
        return new Md5Hash(pwd,salt,hashIterations).toString();
    }
}

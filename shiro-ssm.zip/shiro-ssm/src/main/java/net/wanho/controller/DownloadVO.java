package net.wanho.controller;

import lombok.Data;
import net.wanho.po.Role;

import java.util.Arrays;

@Data
public class DownloadVO extends Role {
    private String type;
    private int[] ids;

    @Override
    public String toString() {
        return "DownloadVO{" +
                "type='" + type + '\'' +
                ", ids=" + Arrays.toString(ids) +
                "} " + super.toString();
    }

}

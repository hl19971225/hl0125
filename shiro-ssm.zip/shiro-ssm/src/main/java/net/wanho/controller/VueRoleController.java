package net.wanho.controller;


import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.enmus.ExcelType;
import com.github.pagehelper.PageInfo;
import net.wanho.exception.ServiceException;
import net.wanho.po.Role;
import net.wanho.service.RoleService;
import net.wanho.util.MyExcelExportStyle;
import net.wanho.vo.AjaxResult;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/role")
public class VueRoleController {

        @Resource
        private RoleService roleService;

        // 查询
        // @RequestMapping("/selectPage")
        // public  AjaxResult  selectPage(@RequestBody RolePageQuery rolePageQuery){
        //     System.out.println("===selectAll===role==="+rolePageQuery);
        //
        //     PageInfo<Role> pageInfo = roleService.selectQuery(rolePageQuery);
        //
        //     return  AjaxResult.success(pageInfo);
        // }

    @RequestMapping("/selectPage/{pageNo}/{pageSize}")
    public  AjaxResult  selectPage( Role role,
                                   @PathVariable  Integer pageNo,
                                   @PathVariable  Integer pageSize){
        System.out.println("===selectAll===role==="+role);
        System.out.println("===selectAll===pageNo==="+pageNo+"===pageSize==="+pageSize);
        PageInfo<Role> pageInfo = roleService.selectQuery(role,pageNo,pageSize);

        return  AjaxResult.success(pageInfo);
    }


        // 支持多选和单选删除
        @RequestMapping("/deleteRole")
        public  AjaxResult  deleteRole(int[] ids){
            System.out.println("===deleteChecked==="+ Arrays.toString(ids));
            roleService.deleteChecked(ids);
            return  AjaxResult.success();
        }


    // 支持批量导入
    @RequestMapping("/insertRole")
    public  AjaxResult  insertRole(@RequestBody  Role role){
        System.out.println("===insertRole==="+ role);
        List<Role> roleList = new ArrayList();
        roleList.add(role);

        try {
             int rows = roleService.insertBatch(roleList);
             return  AjaxResult.success(rows);
        } catch (ServiceException e) {
            return  AjaxResult.failed(e.getMessage());
        }

    }

    @RequestMapping("/updateRole")
    public  AjaxResult  updateRole(@RequestBody Role role ){
        System.out.println("===updateRole==="+ role);

        try {
            roleService.updateRole(role);
            return  AjaxResult.success();
        } catch (ServiceException e) {
            return  AjaxResult.failed(e.getMessage());
        }

    }

    @RequestMapping("/selectById/{id}")
    public  AjaxResult  selectById(@PathVariable  int id){
        System.out.println("===selectById==="+ id);

        Role role = roleService.selectById(id);
        return  AjaxResult.success(role);
    }

    //  EasyPOI 导出
    @RequestMapping("/download")
    public  void   download(DownloadVO downloadVO , HttpServletResponse response) throws IOException {
        System.out.println("===download==="+ downloadVO);
        List<Role> roleList = roleService.selectByDownloadVO(downloadVO);

        // 设置文档标题 和 sheet，默认是 xls 2003
        ExportParams exportParams = new  ExportParams("角色信息","角色信息sheet1", ExcelType.XSSF);
        // 设置样式
        exportParams.setStyle(MyExcelExportStyle.class);
        // 获取Workbook对象
        Workbook workbook = ExcelExportUtil.exportExcel(exportParams, Role.class, roleList);

        // 处理中文乱码的方式
        // String fileName =new String("角色导出.xlsx".getBytes("UTF-8"),"ISO-8859-1");
        // String fileName = URLEncoder.encode("角色导出.xlsx", "UTF-8");

        // response 处理
        // response.reset();
        // response.addHeader("Access-Control-Allow-Origin", "*");
        // response.addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
        // response.addHeader("Access-Control-Allow-Headers", "Content-Type");
        // response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");xlsx格式的Content-Type
        //加在设置response的字符集前面
        response.setCharacterEncoding("utf-8");
        response.setHeader("Content-Disposition","attachment;filename=''");

        OutputStream os = response.getOutputStream();
        workbook.write(os);

        os.close();
        workbook.close();
    }


    //  EasyPOI 导入
    @RequestMapping("/upload")
    public  AjaxResult  upload(MultipartFile file) throws Exception {
        System.out.println("MultipartFile-----"+file.getSize()+"---"+file.getOriginalFilename());
        // 设置导出的参数
        ImportParams importParams = new  ImportParams();
        importParams.setHeadRows(1);// 列名，占一行
        importParams.setTitleRows(1);//标题，占一行
        importParams.setStartSheetIndex(0);//第几个sheet

        List<Role> roleList = ExcelImportUtil.importExcel(file.getInputStream(), Role.class, importParams);
        System.out.println(roleList);

        try {
            int rows = roleService.insertBatch(roleList);
            return  AjaxResult.success(rows);
        } catch (ServiceException e) {
            return  AjaxResult.failed(e.getMessage());
        }
    }


}

package net.wanho.controller;

import net.wanho.po.Menu;
import net.wanho.service.MenuService;
import net.wanho.vo.AjaxResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/menu")
public class VueMenuController {

    @Resource
    private MenuService menuService;

    // 获取登录账号的菜单
    @RequestMapping("/getMyMenu/{account}")
    public AjaxResult getMyMenu(@PathVariable String account){
        List<Menu> menuList =   menuService.getMyMenu(account);
        return  AjaxResult.success(menuList);
    }

    // 获取全部菜单
    @RequestMapping("/getAllMenu")
    public AjaxResult getAllMenu(){
        List<Menu> menuList =   menuService.getAllMenu();
        return  AjaxResult.success(menuList);
    }

    // 新增菜单
    @RequestMapping("/insertMenu")
    public AjaxResult insertMenu(@RequestBody Menu menu){
        System.out.println("====insertMenu===="+menu);
        menuService.insertMenu(menu);
        return  AjaxResult.success();
    }

    // 删除菜单
    @RequestMapping("/deleteMenu/{menuId}")
    public AjaxResult deleteMenu(@PathVariable int menuId){
        System.out.println("====deleteMenu===="+menuId);
        menuService.deleteMenu(menuId);
        return  AjaxResult.success();
    }

}

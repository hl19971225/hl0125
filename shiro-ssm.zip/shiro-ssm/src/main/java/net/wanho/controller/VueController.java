package net.wanho.controller;


import net.wanho.po.User;
import net.wanho.service.LoginService;
import net.wanho.vo.AjaxResult;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/vue")
public class VueController {

        @Resource
        private LoginService loginService;

        // 登录
        @RequestMapping("/login")
        public AjaxResult login(@RequestBody User axiosUser ){
            System.out.println("=====vue====login==== "+axiosUser);

            // 获取主体对象
            Subject subject = SecurityUtils.getSubject();

            //创建令牌
            UsernamePasswordToken token = new  UsernamePasswordToken(axiosUser.getAccount(),axiosUser.getPassword());

            try {
                // 登录认证
                subject.login(token);
                // 使用redis缓存，如果有则使用缓存信息;没有，就查询数据库
                User loginUserInfo = loginService.selectLoginUserInfo((String) subject.getPrincipal());
                return AjaxResult.success(loginUserInfo);
            }catch (UnknownAccountException e){

                return  AjaxResult.failed("用户不存在！！！",null);
            }catch (IncorrectCredentialsException e){

                return  AjaxResult.failed("密码错误！！！",null);
            }

        }

        // 退出
        @GetMapping("/loginOut")
        public  AjaxResult   login(){
            // 获取主体对象
            Subject subject = SecurityUtils.getSubject();
            subject.logout();
            return  AjaxResult.success();
        }


}

package net.wanho.realm;

import net.wanho.po.User;
import net.wanho.service.LoginService;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;

import javax.annotation.Resource;
import java.util.Set;


public class MyRealm extends AuthorizingRealm {

    @Resource
    private LoginService loginService;

    // 认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        // 输入的账号
        String inputAccount = token.getUsername();
        // 输入的密码
        // String inputPwd = new String((char[]) authenticationToken.getCredentials());
        // String inputPwd = new String(token.getPassword());

        User user = loginService.selectByAccount(inputAccount);
        if (user == null){
            // 报错 UnknownAccountException
           return  null;
        }

        // 获取盐值，即用户名
        ByteSource salt = ByteSource.Util.bytes(user.getAccount());
        // 给数据库的密码 按配置的加密方式解密后 和 token里面传过来的值比对，如果不匹配 则报错 IncorrectCredentialsException
        return new SimpleAuthenticationInfo(user.getAccount(), user.getPassword(), salt, getName());
    }

    // 授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {

        String accout = (String) principalCollection.getPrimaryPrincipal();
        System.out.println("====== MyRealm授权 =======" + accout);
        Set<String> roles = loginService.selectRolesByAccout(accout);

        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
        // ---------  Set ---------
        authorizationInfo.setRoles(roles);
        // authorizationInfo.setStringPermissions(new HashSet(Arrays.asList("customer:del", "customer:update", "customer:add")));
        // ---------  List ---------
        // authorizationInfo.addRoles(Arrays.asList("manager", "market"));
        // authorizationInfo.addStringPermissions(Arrays.asList("customer:del", "customer:update", "customer:add"));

        return authorizationInfo;


    }

}

package net.wanho.po;

import lombok.Data;

import java.util.List;

@Data
public class Menu {

    private Integer  menuId;
    private String menuName;
    private String url;
    private Integer parentMenuId;
    private List<Menu> children;// 子菜单
    private int[] checkedRoles;// 绑定角色
}

package net.wanho.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Role implements Serializable {

    private Integer roleId;

    @Excel(name = "角色名称",width = 30)
    private String roleName;

    @Excel(name = "角色标识符",width = 30)
    private String roleKey;

    /*
        @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss") 接收日期类型格式化
        @JsonFormat  传 ajax json数据时候 格式化
    */
    @Excel(name = "创建时间",format="yyyy-MM-dd HH:mm:ss",width = 30)
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;

    @Excel(name = "显示状态(0:正常;1:隐藏)",width = 40)
    private String status;

    @Excel(name = "显示顺序",width = 30)
    private Integer roleSort;

    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createEndTime;

    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;

    private String delFlag;//0未删除 1已删除




}

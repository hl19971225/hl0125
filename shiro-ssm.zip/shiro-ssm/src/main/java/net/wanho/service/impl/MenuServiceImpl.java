package net.wanho.service.impl;

import net.wanho.mapper.MenuMapper;
import net.wanho.po.Menu;
import net.wanho.service.MenuService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional
public class MenuServiceImpl implements MenuService {

    @Resource
    private  MenuMapper menuMapper;

    @Override
    public List<Menu> getMyMenu(String account) {
       List<Menu> parentMenus = menuMapper.getParentMenus(account);
        for (Menu parentMenu : parentMenus) {
            List<Menu> sonMenus = menuMapper.getSonMenus(parentMenu.getMenuId());
            parentMenu.setChildren(sonMenus);
        }
        return parentMenus;
    }

    @Override
    public List<Menu> getAllMenu() {
        List<Menu> parentMenus = menuMapper.getAllParentMenu();
        for (Menu parentMenu : parentMenus) {
            List<Menu> sonMenus = menuMapper.getSonMenus(parentMenu.getMenuId());
            parentMenu.setChildren(sonMenus);
        }
        return parentMenus;

    }

    @Override
    public void insertMenu(Menu menu) {
        menuMapper.insertMenu(menu);
        // 返回主键
        System.out.println(menu.getMenuId());
        if (menu.getCheckedRoles().length>0){
            menuMapper.insertMenuRole(menu.getCheckedRoles(),menu.getMenuId());
        }

    }

    @Override
    public void deleteMenu(int menuId) {
          menuMapper.deleteMenu(menuId);
          List<Menu> sonMenus = menuMapper.getSonMenus(menuId);
         if (!sonMenus.isEmpty()){
             for (Menu sonMenu : sonMenus) {
                 menuMapper.deleteMenu(sonMenu.getMenuId());
             }

         }
    }
}

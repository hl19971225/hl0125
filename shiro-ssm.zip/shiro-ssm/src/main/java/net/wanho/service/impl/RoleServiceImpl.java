package net.wanho.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import net.wanho.controller.DownloadVO;
import net.wanho.exception.ServiceException;
import net.wanho.mapper.RoleMapper;
import net.wanho.po.Role;
import net.wanho.service.RoleService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class RoleServiceImpl implements RoleService {
    @Resource
    private RoleMapper roleMapper;

    @Override
    public List<Role> selectAllRole(Role role) {
        return roleMapper.selectAllRole(role);
    }

    // 多选删除
    @Override
    public void deleteChecked(int[] ids) {
        roleMapper.deleteChecked(ids);
    }

    // 分页查询
    @Override
    public PageInfo<Role> selectQuery(Role role ,Integer pageNo,Integer pageSize) {
        // PageHelper开始
        PageHelper.startPage(pageNo, pageSize);
        List<Role>  roleList = roleMapper.selectAllRole(role);
        return new PageInfo<Role>(roleList);
    }

    @Override
    public int insertBatch(List<Role> roleList) throws ServiceException {
        List<String> nameList = new ArrayList();
        for (Role role : roleList) {
            nameList.add(role.getRoleName());
        }

        List<String> selectRoleName =  roleMapper.checkRoleName(nameList);
        if (!selectRoleName.isEmpty()){
            throw new ServiceException("菜单名重复，操作失败！！！错误的菜单名:"+ selectRoleName);
        }

         return  roleMapper.insertBatch(roleList);


    }

    @Override
    public void updateRole(Role role) throws ServiceException{
        Role  selectRole =  roleMapper.selectByName(role.getRoleName());
        if (selectRole!=null && selectRole.getRoleId()!=role.getRoleId()){
            throw new ServiceException("菜单名重复，操作失败！！！错误的菜单名:[ "+ selectRole.getRoleName()+" ]");
        }
         roleMapper.updateRole(role);
    }

    @Override
    public Role selectById(Integer id) {
        return roleMapper.selectById(id);
    }

    @Override
    public List<Role> selectByDownloadVO(DownloadVO downloadVO) {
        return roleMapper.selectByDownloadVO(downloadVO);
    }
}

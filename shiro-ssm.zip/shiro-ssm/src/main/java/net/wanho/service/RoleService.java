package net.wanho.service;

import com.github.pagehelper.PageInfo;
import net.wanho.controller.DownloadVO;
import net.wanho.exception.ServiceException;
import net.wanho.po.Role;

import java.util.List;

public interface RoleService {
    List<Role> selectAllRole(Role role);

    void deleteChecked(int[] ids);

    PageInfo<Role> selectQuery(Role role ,Integer pageNo,Integer pageSize);

    int insertBatch(List<Role> roleList) throws ServiceException;

    void updateRole(Role role) throws ServiceException;

    Role selectById(Integer id);

    List<Role> selectByDownloadVO(DownloadVO downloadVO);
}

package net.wanho.service.impl;

import net.wanho.mapper.LoginMapper;
import net.wanho.po.User;
import net.wanho.service.LoginService;
import net.wanho.util.RedisUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Set;

@Service
@Transactional
public class LoginServiceImpl implements LoginService {

    @Resource
    private LoginMapper loginMapper;

    @Resource
    private RedisUtil redisUtil;

    @Override
    public User selectByAccount(String account) {
        return loginMapper.selectByAccount(account);
    }

    @Override
    public User selectLoginUserInfo(String account) {
        // 使用redis缓存，如果有则使用缓存信息; 没有，就查询数据库
        User redisUser = redisUtil.get("loginUserInfo:"+ account);
        System.out.println("获取的redis数据-------"+redisUser);

        if (redisUser!= null){
            return redisUser;
        }

        User mysqlUser = loginMapper.selectByAccount(account);
        redisUtil.set("loginUserInfo:"+ account,mysqlUser,0);
        return mysqlUser;
    }

    @Override
    public Set<String> selectRolesByAccout(String accout) {
        return loginMapper.selectRolesByAccout(accout);
    }
}

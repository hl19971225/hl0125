package net.wanho.service;

import net.wanho.po.User;

import java.util.Set;

public interface LoginService {
    // 校验账号
    User selectByAccount(String account);

    User selectLoginUserInfo(String account);

    Set<String> selectRolesByAccout(String accout);

}

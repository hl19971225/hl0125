package net.wanho.service;

import net.wanho.po.Menu;

import java.util.List;

public interface MenuService {
    List<Menu> getMyMenu(String account);

    List<Menu> getAllMenu();

    void insertMenu(Menu menu);

    void deleteMenu(int menuId);

}

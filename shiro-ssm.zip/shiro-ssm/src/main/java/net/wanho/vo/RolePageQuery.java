package net.wanho.vo;

import lombok.Data;
import net.wanho.po.Role;

@Data
public class RolePageQuery  extends Role {

     private Integer pageNo;
     private Integer pageSize;

     @Override
     public String toString() {
          return "RolePageQuery{" +
                  "pageNo=" + pageNo +
                  ", pageSize=" + pageSize +
                  "} " + super.toString();
     }
}

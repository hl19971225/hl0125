package net.wanho.vo;

import lombok.Data;

@Data
public class MenuVO {
    private Integer menuId;
    private String menuName;
    private String url;
    private Integer parentMenuId;
    private int[] checkedRoles;
}

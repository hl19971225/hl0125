package net.wanho.vo;

import lombok.Data;

@Data
public class AjaxResult {
    public  static  final  Integer  STATUS_OK = 200;
    public  static  final  Integer  STATUS_FAILED = 500;
    public  static  final  String  MSG_OK  = "success";
    public  static  final  String  MSG_FAILED = "error";

    private Integer status;
    private String msg ;
    private Object data;

    /**
     * 构造函数私有化
     */
    private AjaxResult(){}


    public static AjaxResult success(  ) {
        return success(MSG_OK,null);
    }

    public static AjaxResult success( Object data ) {
       return success(MSG_OK,data);
    }

    public static AjaxResult success(  String msg ,Object data ) {
        AjaxResult ajaxResult = new AjaxResult();
            ajaxResult.status = STATUS_OK;
            ajaxResult.msg =msg;
            ajaxResult.data = data;
            return ajaxResult;
    }

    public static AjaxResult failed(  ) {
        return failed(MSG_FAILED,null);
    }

    public static AjaxResult failed( Object data ) {
        return failed(MSG_FAILED,data);
    }


    public static AjaxResult failed(  String msg ,Object data ) {
        AjaxResult ajaxResult = new AjaxResult();
            ajaxResult.status = STATUS_FAILED;
            ajaxResult.msg =msg;
            ajaxResult.data = data;
        return ajaxResult;
    }
}

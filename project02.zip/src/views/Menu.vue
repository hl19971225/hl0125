<template>
<div>
    <!-- 新增一级父部门 -->
    <el-row>
        <el-col :span="2">
            <el-button type="success"  icon="el-icon-plus" @click="opendialog('parent')">新增一级父菜单</el-button>
        </el-col>
      </el-row>  

    <!-- 树相关 -->
    <el-row>
    <el-col :span="12">
    <!-- scoped slot 会传入两个参数node和data，分别表示当前节点的 Node 对象和当前节点的数据。    
        <p>使用 scoped slot</p> -->
        <!-- :default-expand-all="false" 是否默认展开所有节点 show-checkbox  显示checkbox -->
        <el-tree
                :data="data"
                
                node-key="id"
                default-expand-all
                expand-on-click-node>
                <span class="custom-tree-node" slot-scope="{ node, data }">
                    <span>{{ node.label }}</span>
                    <span>
                    <el-button
                        v-show="node.level==1"
                        type="text"
                        icon="el-icon-plus"
                        @click="() => append(node,data)">
                        添加子菜单
                    </el-button>
                    <el-button
                        type="text"
                        icon="el-icon-delete"
                        @click="() => remove(node, data)">
                        删除菜单
                    </el-button>
                    </span>
                </span>
            </el-tree>
      </el-col>
      </el-row> 

     <!-- 增加dialog -->
        <el-dialog title="添加菜单" :visible.sync="dialogFormVisible" >
            <el-form :model="dialogForm">
            
                    <el-form-item label="菜单名称:" :label-width="formLabelWidth">
                        <el-input v-model="dialogForm.menuName"></el-input>
                    </el-form-item>
                    <el-form-item label="URL:" :label-width="formLabelWidth">
                        <el-input v-model="dialogForm.url" ></el-input>
                    </el-form-item>

                     <el-form-item v-show="type=='son'" label="父级菜单:" :label-width="formLabelWidth">
                        <el-input v-model="dialogForm.pMenuName" disabled ></el-input>
                    </el-form-item>

                    <el-form-item v-show="type!='son'" label="关联角色:" :label-width="formLabelWidth">
                        <el-select placeholder="请选择关联角色" v-model="dialogForm.checkedRoles" multiple>
                            <el-option v-for="role in roleData" :label="role.label" :value="role.id" :key="role.id"></el-option>
                        </el-select>
                    </el-form-item>
                  
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="success" @click="insertMenu">确 定</el-button>
                <el-button type="primary" @click="dialogFormVisible = false">取 消</el-button>
            </div>
        </el-dialog>

</div>
</template>

<script>
// import  axios  过滤器
import {get,post} from '../utils/request.js';

let id = 1000;

export default {
    name:'Menu',
    data() {
      return {
          data: [],//树的数据
          // ---------- dialogForm ----------
           dialogFormVisible: false,
           formLabelWidth:'120px',
            dialogForm:{
                    menuName:'',
                    url:'',
                    pMenuName:'',
                    parentMenuId:null,
                    checkedRoles:[],
            },
            // ---------- 下拉多选 ----------
             roleData: [
                    {id: 1,label: 'administrator'}, 
                    {id: 2,label: 'market'}, 
                    {id: 3,label: 'HR'}
                ],
             type:'',
        }
    },
    mounted () {
      this.getData();
   },
    methods: {
    // 添加子菜单dialogForm确认
     insertMenu(){
         console.log(this.dialogForm);
         const  url =`/api/menu/insertMenu`;
           
            post(url,this.dialogForm)
                   .then(response => {
                      console.log(response);
                         if(response.status==200){
                              this.$message({
                                type: 'success',
                                message: '添加成功!'
                                });
                            this.dialogFormVisible=false;    
                            this.getData();
                             // this.$emit 改变上下文，调用总线方法, 传递值
                             this.$bus.$emit('reflash',null);
                         }
                   }).catch(error => {
                      // 请求失败，
                     console.log(error);
                  }); 
     },
     // 点击添加子菜单
      append(node,data) {
        //   console.log(node);
        //   console.log(data);
          this.type='son';
          // 赋值给 dialog
          this.dialogForm.parentMenuId=data.id;
          this.dialogForm.pMenuName=data.label;

          this.opendialog();
        },
        // 清空值并打开 dialog
         opendialog(type){
             if(type){
                this.type='';   
                this.dialogForm.parentMenuId=null;
                this.dialogForm.pMenuName='';
             }
             //清空
            this.dialogForm.menuName='';
            this.dialogForm.url='';
            this.dialogForm.checkedRoles=[];
            // 打开 dialog
            this.dialogFormVisible=true;
        },
     // 加载树   
     getData(){
          const  url =`/api/menu/getAllMenu`;
               
            post(url,'')
                   .then(response => {
                    //  console.log(response);
                        const data=[];        
                        response.data.forEach(felement => {
                            // console.log(felement);
                            const menu={};
                            menu.id=felement.menuId;
                            menu.label=felement.menuName;
                            menu.children=[];
                            felement.children.forEach(selement =>{
                                    const smenu={};
                                    smenu.id=selement.menuId;
                                    smenu.label=selement.menuName;
                                    menu.children.push(smenu);
                            })
                            data.push(menu);               
                   })
                    // console.log(data);
                    this.data =data;
                   }).catch(error => {
                      // 请求失败，
                     console.log(error);
                  }); 

        },
     
     // 删除菜单
      remove(node, data) {
       
         this.$confirm('确定删除吗 ???', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                //    console.log(node);
                //    console.log( data.id );
                   const  url =`/api/menu/deleteMenu/${data.id}`;
               
            post(url,'')
                   .then(response => {
                      console.log(response);
                         if(response.status==200){
                              this.$message({
                                type: 'success',
                                message: '删除成功!'
                                });
                              
                            this.getData();
                             // this.$emit 改变上下文，调用总线方法, 传递值
                             this.$bus.$emit("reflash",null);
                         }
                   }).catch(error => {
                      // 请求失败，
                     console.log(error);
                  }); 
                }).catch(() => {
                    this.$message({
                        type: 'warning',
                        message: '取消操作'
                    });          
                });



      },

    
    }
  
}
</script>

<style>
    .custom-tree-node {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 18px;
        padding-right: 8px;
  }
  
</style>
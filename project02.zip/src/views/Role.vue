<template>
<div>
    <!-- =============面包屑==============-->
    <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>系统管理</el-breadcrumb-item>
        <el-breadcrumb-item>角色管理</el-breadcrumb-item>
    </el-breadcrumb>
    <hr>
    <!-- =============查询区域 ===开始==============-->
    <el-form :inline="true" :model="queryRoleForm">
        <el-form-item label="角色名称">
            <el-input v-model="queryRoleForm.roleName"></el-input>
        </el-form-item>
        <el-form-item label="权限字符">
            <el-input v-model="queryRoleForm.roleKey" ></el-input>
        </el-form-item>
        <el-form-item label="状态">
            <el-select v-model="queryRoleForm.status" placeholder="角色状态">
                <el-option label="正常" value="0"></el-option>
                <el-option label="停用" value="1"></el-option>
            </el-select>
        </el-form-item>
        
        <!-- 时间控件 value-format 日期格式化 == @DateTimeFormat-->
               <el-form-item>
                    <el-date-picker
                        value-format="yyyy-MM-dd HH:mm:ss"
                        v-model="timeQuery"
                        type="datetimerange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期">
                    </el-date-picker>
            </el-form-item>
        

        <el-form-item>
            <el-button type="primary" icon="el-icon-search" @click="searchData()">查询</el-button>
            <el-button icon="el-icon-refresh" @click="clear()">重置</el-button>
        </el-form-item>
    </el-form>
    <!-- =============查询区域  ====end==============-->
    <el-row>
        <el-col :span="2">
            <el-button type="success" icon="el-icon-plus" @click="opendialog()">新增</el-button>
        </el-col>
        <el-col :span="2">
            <el-button type="warning" icon="el-icon-edit" :disabled="checkedOne" @click="opendialog(roleIds[0])" >修改</el-button>
        </el-col>
        <el-col :span="2">
            <el-button type="danger" icon="el-icon-delete" :disabled="checkedMore" @click="deleteRole()">删除</el-button>
        </el-col>
        <el-col :span="2">
            <el-button type="primary" icon="el-icon-download"  @click="download">导出</el-button>
        </el-col>
        <!-- auto-upload  手动上传，所以设置为false
             on-preview  点击文件列表中已上传的文件时的钩子
             before-remove  设置before-remove来阻止文件移除操作。
             multiple 是否支持多选文件
             设置limit和on-exceed来限制上传文件的个数和定义超出限制时的行为。
             -->
        <el-col :span="4">
                <el-upload
                    ref="upload"
                    class="upload-demo"
                    accept=".xlsx"
                    action="#"
                    :auto-upload="false"
                    :multiple="false"
                    :limit="1"
                    :on-exceed="handleExceed"
                    :http-request="uploadHttpRequest"
                    :before-upload="beforeUpload"
                    :on-change="handleChange"
                    :on-remove="handleRemove"
                 >
               
                    <el-button slot="trigger" size="small" type="success" icon="el-icon-plus" round>选取文件</el-button>
               
                    <el-button style="margin-left: 10px;" size="small" type="primary" 
                    round icon="el-icon-upload" @click="submitUpload" v-show="ready">导入文件</el-button>
                    
                    <div slot="tip" class="el-upload__tip">（支持xlsx格式文件）</div>
                </el-upload>
        </el-col>

    </el-row>
    <!-- 数据区表格 -->
    <el-table :data="roleList" stripe style="width: 100%"    @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="roleId" label="角色编号" width="150"></el-table-column>
        <el-table-column prop="roleName" label="角色名称" width="150"></el-table-column>
        <el-table-column prop="roleKey" label="角色标识符" width="150"></el-table-column>
        <el-table-column prop="roleSort" label="显示顺序" width="150"></el-table-column>


        <el-table-column prop="status" label="显示状态">
            <template slot-scope="scope">
                <el-switch v-model="scope.row.status" 
                           active-color="#13ce66" inactive-color="#ff4949" 
                           active-value="0" inactive-value="1" @change="statusChange(scope.row.roleId,scope.row.status)" >
                </el-switch>
            </template> 
        </el-table-column>


        <el-table-column prop="createTime" label="创建时间">
        </el-table-column>
        <el-table-column label="操作">
             <template slot-scope="scope">
                    <el-button type="warning" icon="el-icon-edit"  @click="opendialog(scope.row.roleId)"></el-button>
                    <el-button type="danger" icon="el-icon-delete" @click="deleteRole(scope.row.roleId)"></el-button>
             </template> 
        </el-table-column>
    </el-table>

<!-- 分页开始 -->
    <div class="block">
        <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="pageNo"
            :page-sizes="pageSizes"
            :page-size="pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total">
        </el-pagination>
  </div>
<!-- 分页结束 -->


    <!-- 增加 修改dialog -->
<el-dialog :title="dialogFormTitle" :visible.sync="dialogFormVisible" >
    <el-form :model="dialogForm">
    
            <el-form-item label="角色名称:" :label-width="formLabelWidth">
                <el-input v-model="dialogForm.roleName"></el-input>
            </el-form-item>
            <el-form-item label="权限字符:" :label-width="formLabelWidth">
                <el-input v-model="dialogForm.roleKey" ></el-input>
            </el-form-item>
            <el-form-item v-show="selectId" label="状态:" :label-width="formLabelWidth">
                <el-select v-model="dialogForm.status" >
                    <el-option label="正常" :value="'0'"></el-option>
                    <el-option label="停用" :value="'1'"></el-option>
                </el-select>
            </el-form-item>
            <!-- InputNumber 计数器 -->
        <el-form-item label="排序号:" :label-width="formLabelWidth">
             <el-input-number v-model="dialogForm.roleSort"  :min="0" :max="999"  ></el-input-number>
        </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
        <el-button type="success" @click="insertOrUpdateRole">确 定</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">取 消</el-button>
    </div>
</el-dialog>

</div>
</template>

<script>
// import  axios  过滤器
import {get,post,download} from '../utils/request.js';
import qs from 'qs';

export default {
    name: 'Role',
    data() {
        return {
            // form 双向绑定 所以得换 queryData去后台查
            queryRoleForm:{
                roleName:'',
                roleKey:'',
                status:'',
                createTime:null,
                createEndTime:null
            },
            queryData:{}, // 假的存放查询容器
            timeQuery:[],// 时间控件
            roleList: [],// 数据集合
            roleIds:[],//多选删除
            checkedOne:true,//checkbox处理
            checkedMore:true,//checkbox处理
            // 分页相关
            // 当前选中的页 =pageNo
                pageNo:1,
                // 自定义哪些页数供选择
                pageSizes:[5, 10, 15, 20],
                // pageSize
                pageSize:5,
                // 总数据量
                total:100,
                
          // 分页结束----------------
          // ---------- dialogForm ----------
           dialogFormVisible: false,
           formLabelWidth:'120px',
           dialogFormTitle:null,
            dialogForm:{},
            selectId:null,
            //----------文件上传------------
            // fileList: [],
            ready:false,
        }
    },
    // 初始化
    mounted () {
        this.getList();
    },
    methods: {
        //文件状态改变时的钩子，添加文件、上传成功和上传失败时都会被调用
        handleChange(file){
            console.log('handleChange---',file);
            if(file.status=='ready'){
                this.ready=true;
            }
            if(file.status=='success'){
                this.ready=false;
            }
        },
        //文件列表移除文件时的钩子
        handleRemove(){
                console.log('----handleRemove----');
                this.ready=false;
        },
    // 自定义上传方法，param是默认参数，可以取得file文件信息
    uploadHttpRequest(param) {
        console.log('uploadHttpRequest----',param.file);
       
        const formData = new FormData() //FormData对象，添加参数只能通过append('key', value)的形式添加
        formData.append('file', param.file) //添加文件对象
       
        const  url =`/api/role/upload`;
               
            post(url,formData)
                   .then(response => {
                        console.log(response);     
                     if(response.status==500) {
                        this.$message.error(response.data);
                        return
                    }
                    param.onSuccess();  // 上传成功的文件显示绿色的对勾
                     this.$message({
                          type: 'success',
                          message: '导入数据成功! 合计导入'+response.data+'条'
                                     });
                     this.getList();
                       
                   }).catch(error => {
                      // 请求失败，
                     console.log(error);
                  }); 
       
    },

        // 点击上传：手动上传到服务器，此时会触发组件的http-request
        submitUpload(param) {
            this.$refs.upload.submit();
        },
      
        // 上传文件之前的钩子：判断上传文件格式、大小等，若返回false则停止上传,并删除已选中文件
        beforeUpload(file) {
            console.log('-----beforeUpload-----');
            //文件类型
            const isXLSX = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            
            if(!isXLSX) {
                this.$message.error('上传文件只能是xlsx格式，请重新上传！')
            }

            // 文件大小限制为200k
            const fileLimit = file.size / 1024 < 200;
            if(!fileLimit) {
                this.$message.error('上传文件大小不得超过200KB ！');
            }
            return isXLSX && fileLimit
        },
        // 限制上传文件总数
        handleExceed(files, fileList) {
            this.$message.warning("只能上传一个文件！！！");
        },

        //--------文件下载--------------
        download(){
           const keysArr = Object.keys(this.queryData);
           let  url =`/api/role/download`;
           let  params={};
           if(this.roleIds.length != 0){
                params = qs.stringify({ids: this.roleIds}, { indices: false })+'&type=checked';
                url = url + '?'+ params;
                params ='';
            }else if(keysArr != 0){
                Object.assign(params, this.queryData);
                params.type='query';
            }else{
                 params.type='all';
            }
           // console.log('params--------',params);

             download(url,params)
                         .then(data => {
                            let blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
                            let url = window.URL.createObjectURL(blob);
                            // 定义a标签，设置download属性，插入到文档中并click
                                let link = document.createElement('a');
                                link.style.display = 'none';
                                link.href = url;
                                link.download = '角色导出.xlsx';
                                document.body.appendChild(link);
                                link.click();
                                URL.revokeObjectURL(url); // 释放URL 对象
                                document.body.removeChild(link);

                         }).catch(error => {
                            // 请求失败，
                             console.log(error);
                         });  

        },

      //状态按钮切换
      statusChange(id,status){
        //   console.log('statusChange----',id,status);
          const  url =`/api/role/updateRole`;
               
                            post(url,{roleId:id,status})
                                    .then(response => {
                                        if(response.status==200){
                                            
                                            this.getList();
                                        }
                                    }).catch(error => {
                                        // 请求失败，
                                        console.log(error);
                                    }); 
       },
        // 分页 切换 pageSize
         handleSizeChange(val) {
                console.log(`每页 ${val} 条`);
                 this.pageSize=val;
                 this.pageNo=1;
               
                this.getList();
            },
        // 分页 切换 pageNo
        handleCurrentChange(val) {
            console.log(`当前第${val}页`);
            this.pageNo=val;
            
            this.getList();
        },

        getList(){
           
             const  params =this.queryData;
             const  url =`/api/role/selectPage/${this.pageNo}/${this.pageSize}`;
             
                  get(url,params)
                         .then(response => {
                            console.log(response);
                            const page = response.data;
                            this.roleList = page.list;
                            this.total = page.total;
                         }).catch(error => {
                            // 请求失败，
                             console.log(error);
                         });  
        },
        // 查询按钮
        searchData(){
          // console.log('this.timeQuery------------',this.timeQuery);
          // 时间控件
           if(this.timeQuery){
                this.queryRoleForm.createTime=this.timeQuery[0];
                this.queryRoleForm.createEndTime=this.timeQuery[1]; 
           }
         
            /**
             *  es6 的浅拷贝： Object.assign()方法的第一个参数是目标对象，后面的参数都是源对象。
             *  注意，如果目标对象与源对象有同名属性，或多个源对象有同名属性，则后面的属性会覆盖前面的属性。
             */
             Object.assign(this.queryData, this.queryRoleForm);
                this.pageNo=1;
                this.getList();
        },

        // 查询清空按钮
        clear(){
            this.queryRoleForm={
                roleName:'',
                roleKey:'',
                status:'',
                createTime:null,
                createEndTime:null
            };
            this.queryData={};
            this.pageNo=1;
            this.timeQuery =[];
            this.getList();
        },

    // 全选全不选 onchange事件触发
        handleSelectionChange(val) {
            // console.log(val);
            // map是对 原数组做处理
            this.roleIds = val.map(item=>item.roleId);
            //  console.log(this.roleIds);
            this.checkedOne = (this.roleIds.length==1)?false:true;
            this.checkedMore = (this.roleIds.length>0)?false:true;
      },

      deleteRole(roleId){

           this.$confirm('确定删除吗 ???', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {

                     const  url ='/api/role/deleteRole';
                     const  params =  qs.stringify({ids: roleId || this.roleIds}, { indices: false });
                        console.log("params---------",params);

                            post(url,params)
                                    .then(response => {
                                        if(response.status==200){
                                             this.$message({
                                                type: 'success',
                                                message: '删除成功!'
                                            });
                                            this.getList();
                                        }
                                    }).catch(error => {
                                        // 请求失败，
                                        console.log(error);
                                    });  
                
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消操作'
                    });          
                });
           
      },
    //   打开 dialog
            opendialog(id){
                    console.log('opendialog---------',id);

                    if(id){
                           this.selectId = id;//判断是新增还是修改的标识
                           const  url =`/api/role/selectById/${id}`;
                       
                            get(url,'')
                                    .then(response => {
                                        if(response.status==200){
                                            // console.log(response.data);
                                            this.dialogForm=response.data;
                                           
                                            //打开 dialog
                                            this.dialogFormTitle='修改操作';
                                            this.dialogFormVisible =true;
                                        }
                                        
                                    }).catch(error => {
                                        // 请求失败，
                                        console.log(error);
                                    }); 
                    }else{
                          this.selectId = null;//判断是新增还是修改的标识
                          this.dialogFormTitle='新增操作';
                          this.dialogForm={roleSort:0};
                         //打开 dialog
                        this.dialogFormVisible =true;
                    }

            },
              //  dialog添加或修改
            insertOrUpdateRole(){
                    // 修改
                    if(this.selectId){
                         const  url =`/api/role/updateRole`;
                    //    console.log('this.dialogForm-------',this.dialogForm);
                            post(url,this.dialogForm)
                                    .then(response => {
                                        if(response.status==200){
                                             this.$message({
                                                type: 'success',
                                                message: '修改成功!'
                                            });
                                            this.dialogFormVisible =false;
                                            this.getList();
                                        }else{

                                             this.$message.error(response.data);
                                           
                                        }
                                        
                                    }).catch(error => {
                                        // 请求失败，
                                        console.log(error);
                                    }); 
                    }else{
                        //添加
                           const  url =`/api/role/insertRole`;
                       
                            post(url,this.dialogForm)
                                    .then(response => {
                                        if(response.status==200){
                                             this.$message({
                                                type: 'success',
                                                message: '添加成功!'
                                            });
                                             this.dialogFormVisible =false;
                                            this.getList();
                                        }else{

                                             this.$message.error(response.data);
                                           
                                        }
                                        
                                    }).catch(error => {
                                        // 请求失败，
                                        console.log(error);
                                    }); 

                    }

            },
    }

}
</script>

<style>

</style>

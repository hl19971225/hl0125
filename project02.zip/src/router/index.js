import Vue from 'vue'
import Router from 'vue-router'
import Home from '../layout/Home.vue'
import Login from '../layout/Login.vue'
import Role from '../views/Role.vue'
import Menu from '../views/Menu.vue'

Vue.use(Router)

export default new Router({
   /**
     * 通过history api，我们丢掉了丑陋的#，但是它也有个毛病：
     * 不怕前进，不怕后退，就怕刷新，f5，可能 404
     */
    mode: 'history', //hash（默认值）, history
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login
    },
      {
        path: '/home',
        name: 'Home',
        component: Home,
        // props: $route => ({ loginUser: $route.query.loginUser,})
        children:  
          [
            {
            path: 'role',
            name: 'Role',
            component: Role,
           },
           {
            path: 'menu',
            name: 'Menu',
            component: Menu,
           },
        ],
      },
  ]
})

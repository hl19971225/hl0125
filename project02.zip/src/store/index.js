import Vue from 'vue'
import Vuex from "Vuex"
// import 自定义模块
import  token from "./modules/token"

Vue.use(Vuex)


const store =  new Vuex.Store({
    modules: {
        token:token,
       
    }
})


export default store;
// import  axios  过滤器
// import {post} from '../../utils/request.js';

//  模块化 每个模块都有自己的vuex
export default {
    //  设置 namespaced: true 才能使用自定义模块
   namespaced: true,
   name:"token",

   actions:{
    // 参数上下文（默认） 和 值
    // context.commit("ADD",num);
    login(context,data){
        context.commit("LOGIN",data);
      }
    
   },
   mutations:{
     //  ADD_EMP(state,emp)  参数state 和 接收的值
        LOGIN(state,data){
            state.loginUser=data;
        }

   },
   state:{ 
      loginUser:{},
   },
   getters:{ },

}
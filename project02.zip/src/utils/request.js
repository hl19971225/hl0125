import axios from 'axios';

import {MessageBox,Message} from 'element-ui';


axios.defaults.timeout=10000
axios.defaults.baseURL='/'
axios.interceptors.request.use(
        config=>config, 
        error => Promise.reject(error)// 出现异常时的处理
    )
    
axios.interceptors.response.use(
    response=>{
            // console.log("正常响应");
            return response
    },
    error => {
        console.log("响应异常");
        if(error.response){
            const code = error.response.status;
            const errormsg='后端发生错误，请联系管理员';
            if(code == 500){
                Message({
                        message:errormsg,
                        type:'error'
                })   
                return Promise.reject(new Error(errormsg))
            }
        }else{
            let errormsg ="";
            if(error.message.includes('timeout')){
                errormsg='连接超时';
             }
             Message({
                message:errormsg,
                type:'error'
            }) 
            console.log('error.message-----'+error);
            return Promise.reject(new Error(errormsg))
        }
    }
)

export function get(url,params={}){
     return new Promise((resolver,reject)=>{
        // console.log(params);
        
         //发请求
        axios.get(url,{params})
            .then(response=>resolver(response.data))
            .catch(error=>reject(error))

     })
}

export function download(url,params={}){
    return new Promise((resolver,reject)=>{
       //发请求
       axios.get(url,{ params,
                       responseType:'blob' })
           .then(response=>resolver(response.data))
           .catch(error=>reject(error))

    })
}

export function post(url,data={}){
    return new Promise((resolver,reject)=>{
        //发请求
       axios.post(url,data)
        .then(response=>{
            // console.log("post-----",response)
            return resolver(response.data)
        })
        .catch(error=>{
            console.log(error)
            return  reject(error)
        })

    })
}
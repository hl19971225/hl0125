// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Element from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css';
import store from './store/index'

Vue.use(Element)
Vue.config.productionTip = false

// 解决vue-router 多次点击导航， 
// 报NavigationDuplicated: Avoided redundant navigation to current location 的问题
const originalPush = router.push

router.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>',
  // 定义一个全局的事件总线
  beforeCreate(){
    Vue.prototype.$bus=this;
  },
})

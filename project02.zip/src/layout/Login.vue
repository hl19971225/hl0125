<template>
<div>
    <el-form :model="loginForm"   label-width="100px" >
            <el-form-item label="用户:" >
                <el-input type="text" v-model="loginForm.account" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="密码:" >
                <el-input type="password" v-model="loginForm.password" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="验证码:" >
                <el-input type="text" v-model="loginForm.checkcode" autocomplete="off"></el-input>
                
                <my-identify :callback="getMycheckcode"></my-identify>
            </el-form-item>
            
            <el-form-item>
                <el-button type="primary"  @click="submitForm()">登录</el-button>
                <el-button @click="resetForm()">重置</el-button>
            </el-form-item>
    </el-form>

 </div>
</template>

<script>
// import  axios  过滤器
import {post} from '../utils/request.js';

import MyIdentify from './Identify.vue';
export default {
      name:"Login",
      components: {
        MyIdentify
      },
      data () {
          return {
             loginForm:{account:"",password:"",checkcode:""},
             mycheckcode:'',
         }
      },
     
      methods: {
        
         getMycheckcode(code){
                this.mycheckcode=code;
             },
             submitForm(){
                 console.log('mycheckcode------'+ this.mycheckcode);
                 console.log(this.loginForm.checkcode);
                 if(this.mycheckcode.toLowerCase()!=this.loginForm.checkcode.toLowerCase()){
                        this.$message.error("验证码输入错误！！！");
                        return
                 }
                
                   const  url ='/api/vue/login';
                   const  params = this.loginForm;
                   
                        post(url,params)
                            .then(response => {
                           
                               // 登陆失败
                                if(response.status==500){
                                    // alert(response.msg);
                                   this.$message.error(response.msg);
                                    return;
                                }
                               
                            // vuex 存入用户信息,但不能刷新页面
                            // this.$store.dispatch("token/login", response.data);

                            // 存入缓存中
                           window.sessionStorage.setItem("loginUser", JSON.stringify(response.data)); 
                            
                           // 登陆成功 跳转
                            this.$router.push({ name:'Home',})

                            
                            }).catch(error => {
                                // 请求失败，
                                console.log(error);
                            });  
                    
                     } ,
             resetForm(){
                    this.loginForm={account:"",password:""};
             },
      },
  }
</script>
<template>

     <el-container >
        <!-- {{$route.params.loginUser}} -->
          <el-header>
                <!-- 标题 -->
                <!-- <app-header :loginUser="$route.params.loginUser"></app-header> -->
                <!-- <app-header :loginUser="this.loginUser"></app-header> -->
                <app-header ></app-header>
            
            </el-header>
          <el-container>
            <el-aside width="200px">
                  <app-aside ></app-aside>
            </el-aside>
              <el-main>
                  
                  <app-main></app-main>
              </el-main>
              
          </el-container>
          
</el-container>

   
</template>

<script>
import AppAside from './components/AppAside.vue'
import AppHeader from './components/AppHeader.vue'
import AppMain from './components/AppMain.vue'

export default {
    name:'Home',
    components: { AppHeader, AppAside, AppMain },
    // props: ['loginUser'],
  
}
</script>

<style>

    .el-header, .el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
  }
  
  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: center;
    line-height: 200px;
   
  }
  
  .el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    /* line-height: 160px; */
    background-image: url('../assets/img.jpg');
    background-repeat: no-repeat;   
    background-size: 100% 100%;
  }
  
  body > .el-container {
    margin-bottom: 40px;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }
</style>
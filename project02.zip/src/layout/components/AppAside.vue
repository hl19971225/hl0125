<template>
      <!-- default-active="1" 	当前激活菜单的 index -->
           <el-menu
                
                class="el-menu-vertical-demo"
                @open="handleOpen"
                @close="handleClose"
                background-color="#545c64"
                text-color="#fff"
                active-text-color="#ffd04b">

          <el-submenu  v-for="pMenu in menuList" :index="pMenu.menuId+''" :key="pMenu.menuId">
                    <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>{{pMenu.menuName}}</span>
                    </template>
                    <el-menu-item-group>
                        <el-menu-item v-for="cMenu in pMenu.children" 
                         :key="cMenu.menuId" :index="cMenu.menuId+''"
                          @click="changeView(cMenu.url)" >
                            <i class="el-icon-s-flag"></i>
                              {{cMenu.menuName}}
                        </el-menu-item>
                     </el-menu-item-group>
                </el-submenu>

           
            </el-menu>

</template>

<script>
// import  axios  过滤器
import {get,post} from '../../utils/request.js';

export default {
    name:'AppAside',
    data () {
        return {
            // menuList:[
            //     {menuId:'1',menuName:'系统设置',children:[{menuId:'1-1',menuName:'用户管理',url:'user'},{menuId:'1-2',menuName:'角色管理',url:'role'}]},
            //     {menuId:'2',menuName:'库存管理',children:[{menuId:'2-1',menuName:'库存管理'},{menuId:'2-2',menuName:'商品管理'}]},
            //     ],
             menuList:[],
             account : JSON.parse(sessionStorage.getItem("loginUser")).account,
        }
    },
    mounted () {
      // console.log('account-----',account);
      this.getMyMenu(this.account);
      // 添加新菜单后刷新
      this.$bus.$on("reflash",this.reflash);// 参数是个 function
    },
   methods: {
     reflash(){
          // console.log('reflash----------');
           this.getMyMenu(this.account);
     },
      getMyMenu(account){
            
             const  url =`/api/menu/getMyMenu/${account}`;
             
                  get(url,'')
                         .then(response => {
                            // console.log(response);
                            this.menuList=response.data;
                         }).catch(error => {
                            // 请求失败，
                             console.log(error);
                         });  
      },
      handleOpen(key, keyPath) {
        // console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        // console.log(key, keyPath);
      },
       changeView(url){
          // console.log(url);
            this.$router.push({ path :'/home'+url,})
      },
    },
     
}
</script>

<style>
  
</style>
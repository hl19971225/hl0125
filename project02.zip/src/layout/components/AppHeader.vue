<template>
    <div>
        <!-- {{$store.state.token.loginUser}} -->
        <span>vue 管理系统 欢迎您：{{this.loginUser.username}}</span>  &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp;
       
        <button @click="loginOut()">退出系统</button>
    </div>
</template>

<script>
// import  axios  过滤器
import {get} from '../../utils/request.js';

export default {
    name:'AppHead',
    // props: ['loginUser'],
    computed: {
        loginUser(){
            
             return JSON.parse(sessionStorage.getItem("loginUser"))   //取  
        }
       
    },
    methods: {
        loginOut(){
                 const  url ='/api/vue/loginOut';
                         get(url,'')
                                .then(response => {
                            
                                    // 请求成功返回值
                                    if(response.status==200){
                                            this.$router.replace({ 
                                                name:'Login',
                                            
                                        })

                                    }

                                
                                }).catch(error => {
                                    // 请求失败，
                                    console.log(error);
                                });  

             

        }
    },
}
</script>

<style scoped>
    span{
        color: palevioletred;
    }
</style>
package com.huawei.eduservice.controller;


import com.huawei.eduservice.entity.EduTeacher;
import com.huawei.eduservice.service.EduTeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 讲师 前端控制器
 * </p>
 *
 * @author hl
 * @since 2022-07-06
 */
@RestController
@RequestMapping("/eduservice/edu-teacher")
public class EduTeacherController {


    @Autowired
    private EduTeacherService teacherService;

    @GetMapping("findAll")
    public List<EduTeacher> list(){
        List<EduTeacher> list = teacherService.list(null);
        return list;
    }

    @DeleteMapping("{id}")
    public boolean removeById(@PathVariable String id){
        return teacherService.removeById(id);
    }
}


package com.huawei.eduservice.service;

import com.huawei.eduservice.entity.EduTeacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 讲师 服务类
 * </p>
 *
 * @author hl
 * @since 2022-07-06
 */
public interface EduTeacherService extends IService<EduTeacher> {

}
